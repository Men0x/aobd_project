import xgboost as xgb
from xgboost import XGBClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

import mlflow

import pandas as pd
import seaborn as sns
import numpy as np
import os
import matplotlib.pyplot as plt
import re

def preprocessing():
    train = pd.read_csv('application_train.csv')
    test = pd.read_csv('application_test.csv')

    ###LABEL ENCODING

    le = LabelEncoder()

    for col in train:
        if train[col].dtype == 'object':
    # If 2 or fewer unique categories
            if len(list(train[col].unique())) <= 2:
                le.fit(train[col])
                train[col] = le.transform(train[col])
                test[col] = le.transform(test[col])

    ###ONE HOT ENCODING

    train = pd.get_dummies(train)
    test = pd.get_dummies(test)

    labels = train['TARGET']

    ###ALIGN TRAIN AND TEST

    train, test = train.align(test, join='inner', axis=1)
    train['TARGET'] = labels

    return train